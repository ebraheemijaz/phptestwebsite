<?php


session_start();
if (isset($_SESSION['usuario'])){
  if($_SESSION['usuario']['tipo'] != "Usuario"){
    header('location: ../Admin/');
  }
} else {
    header('location: ../../');
    }
$DBservername = "dbhamse.cgykoqp1l4le.us-east-1.rds.amazonaws.com:3306";
$DBusername = "lance";
$DBpassword = "7201mega";
$MYDB = "dbhamsecon";
$link = mysqli_connect($DBservername,$DBusername,$DBpassword,$MYDB);

// Check connection
if (mysqli_connect_errno() || !$link)
  {
  echo "Fallo al Conectarse a SQL: " . mysqli_connect_error();
  exit;
  }
 
    
?>
<!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
<h1>Bienvenido <?php echo $_SESSION ['usuario']['nombres']?></h1>
<a href="../salir.php">Cerrar sesión</a>
<!DOCTYPE html>
<html lang="es_MX">
<head>
  <title>Portal de Consultas Comercializadora Hamse</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>


<table class="table table-striped">
  	
		<thead>
		<tr>
			<th>FOLIO</th>
			<th>CENTRO DE ENTREGA</th>
			<th>DESTINO</th>
            <th>PRODUCTO</th>
            <th>TURNO</th>
            <th>CLAVE</th>
						<th>TRANSPORTISTA</th>
						<th>CAPACIDAD</th>
						<th>FECHA DE FACTURACION</th>
						<th>ESTADO DEL PEDIDO</th>
		</tr>
		</thead>
<?php

foreach ($link->query('SELECT consult.*
FROM consult,usuarios 
 WHERE usuarios.destino = consult.destino and usuarios.id='. $_SESSION['usuario']['id']) 
as $row){ // aca puedes hacer la consulta e iterarla con each. 
?> 
  <tr>
    <td><?php echo $row['Folio_pedido'] // aca te faltaba poner los echo para que se muestre el valor de la variable.  ?></td>
      <td>
  <?php
   echo $row['Centro_de_entrega'] ?></td>
  <td>
  <?php
   echo $row['Destino'] ?></td>
      <td><?php
   echo $row['Producto'] ?></td>
  <td><?php
   echo $row['Turno'] ?></td>
  <td><?php
   echo $row['Clave'] ?></td>
  <td><?php
   echo $row['Transportista'] ?></td>
  <td><?php
   echo $row['Capacidad_programada'] ?></td>
  <td><?php
   echo $row['facturacion'] ?></td>
  <td><?php
   echo $row['Estado_de_atencion'] ?></td>

  
  <?php
	}
?>
	

</table>
</body>
</html>
