<!DOCTYPE html>
<html lang="es_MX">
<head>
  <title>Portal de Consultas Comercializadora Hamse</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<h1>Bienvenido usuario</h1>

<table class="table table-striped">
  	
		<thead>
		<tr>
			<th>FOLIO</th>
			<th>CENTRO DE ENTREGA</th>
			<th>DESTINO</th>
            <th>PRODUCTO</th>
            <th>TURNO</th>
            <th>CLAVE</th>
						<th>TRANSPORTISTA</th>
						<th>CAPACIDAD</th>
						<th>FECHA DE FACTURACION</th>
						<th>ESTADO DEL PEDIDO</th>
						<th>HORA DE CONSULTA</th>
			
		</tr>
		</thead>
<?php

foreach ($link->query('SELECT usuario, destino 
FROM usuarios 
WHERE usuario=? AND destino=? 
UNION 
SELECT * 
FROM consulta 
WHERE destino=? ') as $row){ // aca puedes hacer la consulta e iterarla con each. ?> 
<tr>
	<td><?php echo $row['folio'] // aca te faltaba poner los echo para que se muestre el valor de la variable.  ?></td>
    <td>
<?php
 echo $row['entrega'] ?></td>
<td>
<?php
 echo $row['destino'] ?></td>
    <td><?php
 echo $row['producto'] ?></td>
<td><?php
 echo $row['turno'] ?></td>
<td><?php
 echo $row['clave'] ?></td>
<td><?php
 echo $row['transportista'] ?></td>
<td><?php
 echo $row['capacidad'] ?></td>
<td><?php
 echo $row['fecha'] ?></td>
<td><?php
 echo $row['estado'] ?></td>
<td><?php
 echo $row['consultacol'] ?></td>

 </tr>
<?php
	}
?>
</table>
</body>
</html>