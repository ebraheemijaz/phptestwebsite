<?php
session_start();
if (isset($_SESSION['usuario'])){
  if($_SESSION['usuario']['tipo'] != "Admin"){
    header('location: ../Usuario/');
  }
} else {
    header('location: ../../');
    }
?>

<!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <title></title>
   </head>
   <body>
<h1>Bienvenido <?php echo $_SESSION ['usuario']['nombres']?></h1>
<a href = '../salir.php'>Cerrar Sesion </a>
<?php


// Te recomiendo utilizar esta conección, la que utilizas ya no es la recomendada. 
$link = new PDO('mysql:host=dbhamse.cgykoqp1l4le.us-east-1.rds.amazonaws.com:3306;dbname=dbhamsecon', 'lance', '7201mega'); // el campo vaciío es para la password. 

?>

<table class="table table-striped">
  	
		<thead>
		<tr>
			<th>FOLIO</th>
			<th>CENTRO DE ENTREGA</th>
			<th>DESTINO</th>
            <th>PRODUCTO</th>
            <th>TURNO</th>
            <th>CLAVE</th>
						<th>TRANSPORTISTA</th>
						<th>CAPACIDAD</th>
						<th>FECHA DE FACTURACION</th>
						<th>ESTADO DEL PEDIDO</th>
						<th>HORA DE CONSULTA</th>
			
		</tr>
		</thead>
<?php

foreach ($link->query('SELECT * from consulta order by consultacol desc LIMIT 250') as $row){ // aca puedes hacer la consulta e iterarla con each. ?> 
<tr>
	<td><?php echo $row['folio'] // aca te faltaba poner los echo para que se muestre el valor de la variable.  ?></td>
    <td>
<?php
 echo $row['centro_entrega'] ?></td>
<td>
<?php
 echo $row['destino'] ?></td>
    <td><?php
 echo $row['producto'] ?></td>
<td><?php
 echo $row['turno'] ?></td>
<td><?php
 echo $row['clave'] ?></td>
<td><?php
 echo $row['transportista'] ?></td>
<td><?php
 echo $row['capc'] ?></td>
<td><?php
 echo $row['factura'] ?></td>
<td><?php
 echo $row['status'] ?></td>
<td><?php
 echo $row['consultacol'] ?></td>

 </tr>
<?php
	}
?>
</body>
 </html>